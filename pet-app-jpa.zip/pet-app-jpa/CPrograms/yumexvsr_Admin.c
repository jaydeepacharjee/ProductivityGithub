#include<stdio.h> 
 int main(){
 int i; 
 for (i = 1; i < 11; ++i){
 printf("%d ", i
); }
 return 0;}