#include<stdio.h>
int main(){
     printf("Hello Jaydeep");
     return 0
}