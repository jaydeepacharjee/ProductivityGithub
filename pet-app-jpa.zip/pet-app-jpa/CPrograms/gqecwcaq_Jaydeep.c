#include<stdio.h>
int main(){
     printf("Hi Jaydeep");
     return 0;
}