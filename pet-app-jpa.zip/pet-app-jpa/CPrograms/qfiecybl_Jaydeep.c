#include<stdio.h>
int main()
     printf("My name is corinavirus");
     return 0;
}