class fP1ChPC3A8_Jaydeep{
     public static void main(String[] args){
          System.out.println(Hello World Jaydeep");
     }
}