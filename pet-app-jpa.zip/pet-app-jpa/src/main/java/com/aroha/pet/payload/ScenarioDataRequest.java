package com.aroha.pet.payload;

public class ScenarioDataRequest {

	 private int scenarioId;
	 private String scenarioTitle;
	 
	public int getScenarioId() {
		return scenarioId;
	}
	public void setScenarioId(int scenarioId) {
		this.scenarioId = scenarioId;
	}
	public String getScenarioTitle() {
		return scenarioTitle;
	}
	public void setScenarioTitle(String scenarioTitle) {
		this.scenarioTitle = scenarioTitle;
	}
	
	 
	 
	 
	
}
