package com.aroha.pet.exception;

public class FileNotFoundException extends RuntimeException {

	public FileNotFoundException(String s) {
		super(s);
	}
}
