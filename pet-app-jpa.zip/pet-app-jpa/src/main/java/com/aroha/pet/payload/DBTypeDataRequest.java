package com.aroha.pet.payload;

public class DBTypeDataRequest {

	  private long id;
	  private String dbType;
	  private String dbName;
	  
	  
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getDbType() {
		return dbType;
	}
	public void setDbType(String dbType) {
		this.dbType = dbType;
	}
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	  
	  
	  
	
}
