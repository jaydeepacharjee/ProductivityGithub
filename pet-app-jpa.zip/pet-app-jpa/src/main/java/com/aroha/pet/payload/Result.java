package com.aroha.pet.payload;

/**
 *
 * @author Jaydeep
 */
public class Result {
    
    int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
    
}
