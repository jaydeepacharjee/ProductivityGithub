package com.aroha.pet.payload;

import com.aroha.pet.model.JavaPojo;

public class JavaPayload {
	
	private int questionId;
	private JavaPojo javapojo;
	
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public JavaPojo getJavapojo() {
		return javapojo;
	}
	public void setJavapojo(JavaPojo javapojo) {
		this.javapojo = javapojo;
	}

   
	
	

}
