package com.aroha.pet.payload;

/**
 *
 * @author Jaydeep
 */
public class FeedBackException {

    private String exceptionStr;


    public String getExceptionStr() {
        return exceptionStr;
    }

    public void setExceptionStr(String exceptionStr) {
        this.exceptionStr = exceptionStr;
    }

}
