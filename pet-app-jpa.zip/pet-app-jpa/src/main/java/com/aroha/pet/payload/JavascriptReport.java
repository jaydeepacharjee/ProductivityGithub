package com.aroha.pet.payload;

public class JavascriptReport {
	
    private java.math.BigInteger userId;
    private String created_at;
    private String name;
    private java.math.BigInteger noOfError;
    private java.math.BigInteger noOfQuestion;
    private java.math.BigInteger noOfAttempt;
    private java.math.BigDecimal productivity;
	public java.math.BigInteger getUserId() {
		return userId;
	}
	public void setUserId(java.math.BigInteger userId) {
		this.userId = userId;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public java.math.BigInteger getNoOfError() {
		return noOfError;
	}
	public void setNoOfError(java.math.BigInteger noOfError) {
		this.noOfError = noOfError;
	}
	public java.math.BigInteger getNoOfQuestion() {
		return noOfQuestion;
	}
	public void setNoOfQuestion(java.math.BigInteger noOfQuestion) {
		this.noOfQuestion = noOfQuestion;
	}
	public java.math.BigInteger getNoOfAttempt() {
		return noOfAttempt;
	}
	public void setNoOfAttempt(java.math.BigInteger noOfAttempt) {
		this.noOfAttempt = noOfAttempt;
	}
	public java.math.BigDecimal getProductivity() {
		return productivity;
	}
	public void setProductivity(java.math.BigDecimal productivity) {
		this.productivity = productivity;
	}
    
    

}
