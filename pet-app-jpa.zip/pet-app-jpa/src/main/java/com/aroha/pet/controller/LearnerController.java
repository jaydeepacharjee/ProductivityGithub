package com.aroha.pet.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Sony George | Date : 5 Mar, 2019 4:43:42 PM
 */
@RestController
@RequestMapping("/api/learner")
public class LearnerController {

	
	
}
